package cl.aligare.entity;
import lombok.Data;

@Data
public class TrxData
{
    public Invoice invoice;
}


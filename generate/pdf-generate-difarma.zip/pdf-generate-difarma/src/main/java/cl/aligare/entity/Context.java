package cl.aligare.entity;
import lombok.Data;

@Data
public class Context
{
    public String idCompany;
    public String idCountry;
    public String idStore;
    public String idChannel;
}


package cl.aligare.entity;
import lombok.Data;

@Data
public class Point
{
    public int points;
    public int campaign;
    public int validity;
}


package cl.aligare.entity;
import lombok.Data;

@Data
public class Attribute
{
    public String name;
    public String value;
}


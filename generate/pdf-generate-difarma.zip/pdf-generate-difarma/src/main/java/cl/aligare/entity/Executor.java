package cl.aligare.entity;
import lombok.Data;

@Data
public class Executor
{
    public String executorId;
    public String firstName;
    public String middleName;
    public String lastName;
    public String email;
}


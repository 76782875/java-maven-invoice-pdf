package cl.aligare.entity;
import lombok.Data;



import java.util.List;
@Data
public class PaymentGroups
{
    public List<Payment> payment;
}


package cl.aligare.entity;

import java.util.List;
import lombok.Data;

@Data
public class Attributes
{
    public List<Attribute> attribute;
}


package cl.aligare.entity;
import lombok.Data;

@Data
public class Cashier
{
    public String cashierId;
    public String posId;
}


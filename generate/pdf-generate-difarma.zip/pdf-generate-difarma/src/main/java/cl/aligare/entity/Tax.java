package cl.aligare.entity;
import lombok.Data;

@Data
public class Tax
{
    public String taxCode;
    public int taxAmount;
}


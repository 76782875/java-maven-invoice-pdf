package cl.aligare.entity;
import lombok.Data;

@Data
public class TrxIdentify
{
    public int orderType;
    public int idEvent;
    public String idOrder;
}

